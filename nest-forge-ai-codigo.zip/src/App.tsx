import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { ChatMessage, Project, ProjectFile, ProjectMeta, ProjectVersion } from './types';
import type { FileOp } from './providers/Provider';
import { newId, nowIso, toMeta } from './types';
import { IndexedDBStorage } from './storage/IndexedDBStorage';
import { DemoProvider } from './providers/DemoProvider';
import { applyOps, validateOps } from './providers/validateOps';
import { extractBusinessName } from './templates';
import { draftKey, pathsForProject, copyProjectDrafts, withoutDraft, withoutFiles, withoutProjectDrafts, readDraftsMirror, writeDraftsMirror, mergeDrafts } from './editor/drafts';
import { buildPreviewHtml } from './preview/buildPreviewHtml';
import { downloadBlob, exportProjectZip, overlayDrafts } from './export/exportZip';
import { snapshotBeforeSave, appendVersion, nextVersionNumber } from './versions/snapshot';
import Sidebar from './components/Sidebar';
import ChatPanel from './components/ChatPanel';
import PreviewPanel from './components/PreviewPanel';
import FileExplorer from './components/FileExplorer';
import CodeEditor from './components/CodeEditor';
import VersionsPanel from './components/VersionsPanel';
import Modal from './components/Modal';

type CenterTab = 'chat' | 'files' | 'versions';
type MobileView = 'projects' | 'chat' | 'code' | 'preview';

const PATH_RE = /^[A-Za-z0-9][A-Za-z0-9_.-]*$/;
const ALLOWED_EXT = ['.html', '.css', '.js', '.json', '.md', '.txt', '.svg'];

/**
 * Fusiona el resultado del motor con el estado ACTUAL de los archivos, en
 * vez de imponer la foto tomada al enviar el mensaje.
 *
 * Mientras el motor genera, el usuario puede seguir editando el mismo
 * proyecto (el chat es lo único que se desactiva): guardar a mano, crear
 * o borrar un archivo. El cierre anterior aplicaba el resultado sobre la
 * foto del envío y esas ediciones se perdían en silencio — el mismo fallo
 * que las correcciones del 02 y 03-11 ya cerraron para cambiar/renombrar
 * de proyecto y para el renombre durante la generación.
 *
 * - Las operaciones del motor se aplican sobre `baseFiles` (el estado en
 *   pantalla o guardado en este momento), no sobre la foto.
 * - Una operación que ya no encaja (crear un archivo que el usuario creó
 *   entretanto, actualizar o borrar uno que ya borró) se salta y se avisa
 *   en el chat; las demás se aplican igual.
 * - La versión "antes del motor" guarda `baseFiles`, el estado real justo
 *   antes de aplicar los cambios: si el motor sobrescribe un archivo que
 *   el usuario editó entretanto, esa edición sigue siendo restaurable.
 * - Los borradores solo se descartan para archivos que el motor cambió de
 *   verdad: un borrador en un archivo cuya operación se saltó sobrevive.
 * - Las versiones y los mensajes VIVOS se conservan, no se imponen los
 *   de la foto: un guardado a mano, un borrado o una restauración hechos
 *   mientras generaba crean versiones (y la restauración un mensaje) que
 *   el cierre anterior tiraba al reemplazar la lista por la de la foto.
 *   La versión del motor se añade AL FINAL de la lista viva — es el
 *   punto de retorno más reciente (su contenido es el estado justo antes
 *   de aplicar los cambios) — así su número es siempre el siguiente y
 *   nunca choca con el de una versión creada entretanto.
 */
interface EngineMerge {
  files: ProjectFile[];
  versions: ProjectVersion[];
  messages: ChatMessage[];
  appliedPaths: string[];
}

function mergeEngineResult(
  p: Project,
  versionId: string,
  summaryId: string | null,
  ops: FileOp[],
  baseFiles: ProjectFile[],
  liveVersions: ProjectVersion[],
  liveMessages: ChatMessage[],
  drafts: Record<string, string>,
): EngineMerge {
  const version = p.versions.find((v) => v.id === versionId);
  const beforeFiles = version?.files ?? p.files;
  const basePaths = new Set(baseFiles.map((f) => f.path));
  const applicable = ops.filter((op) =>
    op.kind === 'create_file' ? !basePaths.has(op.path) : basePaths.has(op.path),
  );
  const skipped = ops.filter((op) => !applicable.includes(op));
  const mergedFiles = applyOps(baseFiles, applicable, p.updatedAt);
  // La versión del motor va al final de la lista viva (ver el comentario
  // del encabezado): nunca se tira una versión creada entretanto ni se
  // renumeran las que el usuario ya vio en el panel.
  const existingEngineVersion = liveVersions.find((v) => v.id === versionId);
  // El número es uno más que la última versión viva (no length + 1:
  // el historial tiene tope y length deja de crecer al podar, ver
  // versions/snapshot.ts), así que nunca choca con el de una versión
  // creada entretanto ni se reutiliza el de una ya podada.
  const finalVersionNumber = existingEngineVersion?.versionNumber ?? nextVersionNumber(liveVersions);
  const versions = !version
    ? liveVersions
    : existingEngineVersion
      ? liveVersions.map((v) =>
          v.id === versionId ? { ...v, files: baseFiles.map((f) => ({ ...f })) } : v,
        )
      : appendVersion(liveVersions, { ...version, versionNumber: finalVersionNumber, files: baseFiles.map((f) => ({ ...f })) });
  const overwrittenPaths = applicable
    .filter((op) => op.kind === 'update_file')
    .map((op) => op.path)
    .filter((path) => {
      const now = baseFiles.find((f) => f.path === path);
      const was = beforeFiles.find((f) => f.path === path);
      return !!now && !!was && now.content !== was.content;
    });
  const appliedPaths = applicable.map((op) => op.path);
  const discardedDrafts = appliedPaths.filter((path) => draftKey(p.id, path) in drafts);

  const notes: string[] = [];
  if (skipped.length > 0) {
    notes.push(
      `Nota: mientras el motor generaba editaste archivos y ${skipped.length === 1 ? 'este cambio ya no encajaba' : 'estos cambios ya no encajaban'}: ${skipped.map((o) => o.path).join(', ')}. No se aplicaron y tus ediciones se conservaron.`,
    );
  }
  if (overwrittenPaths.length > 0) {
    notes.push(
      `Nota: habías editado ${overwrittenPaths.join(', ')} mientras generaba y el motor sobrescribió ${overwrittenPaths.length === 1 ? 'ese archivo' : 'esos archivos'}; tu versión quedó guardada en la v${finalVersionNumber} y puedes restaurarla desde Versiones.`,
    );
  }
  if (discardedDrafts.length > 0) {
    notes.push(
      `Nota: tenías cambios sin guardar en ${discardedDrafts.join(', ')} y el motor acaba de modificar esos archivos, así que descarté esos borradores para no sobrescribir el cambio. Guarda antes de pedir cambios la próxima vez para conservar tus ediciones.`,
    );
  }
  // Los mensajes vivos se conservan (una restauración hecha mientras
  // generaba añade uno) y solo se agregan los del motor que aún no están
  // — el plan y el resumen — en vez de imponer la lista de la foto.
  const liveMessageIds = new Set(liveMessages.map((m) => m.id));
  const engineMessages = p.messages.filter((m) => !liveMessageIds.has(m.id));
  let messages = [...liveMessages, ...engineMessages];
  if (notes.length > 0 && summaryId !== null) {
    messages = messages.map((m) =>
      m.id === summaryId ? { ...m, content: m.content + '\n\n' + notes.join('\n\n') } : m,
    );
  }
  return { files: mergedFiles, versions, messages, appliedPaths };
}

function starterFor(name: string): string {
  if (name.endsWith('.html')) {
    return '<!DOCTYPE html>\n<html lang="en">\n<head>\n  <meta charset="UTF-8" />\n  <meta name="viewport" content="width=device-width, initial-scale=1.0" />\n  <title>New page</title>\n</head>\n<body>\n  <h1>Hello</h1>\n</body>\n</html>\n';
  }
  if (name.endsWith('.css')) return '/* styles */\n';
  if (name.endsWith('.js')) return '// scripts\n';
  return '';
}

function welcomeMessage(): ChatMessage {
  return {
    id: newId(),
    role: 'assistant',
    createdAt: nowIso(),
    kind: 'info',
    content:
      'Bienvenido a NEST Forge AI (modo demo). Describe el sitio web que quieres — por ejemplo "Crea el sitio de un restaurante llamado Casa Verde" — y lo construyo con plantillas reales. Después pide cambios como "cambia el título principal a …" o "agrega una sección de precios".',
  };
}

export default function App() {
  const storageRef = useRef(new IndexedDBStorage());
  const providerRef = useRef(new DemoProvider());
  const readyRef = useRef(false);
  const draftsTimerRef = useRef<number | null>(null);
  // Ids de proyectos ya eliminados: un guardado pendiente del proyecto
  // borrado no debe resucitarlo en IndexedDB cuando se cambia al
  // siguiente proyecto (ver flushBeforeSwitch).
  const deletedIdsRef = useRef<Set<string>>(new Set());
  // Número de secuencia de la selección de proyecto: dos toques rápidos
  // en la lista lanzan dos lecturas asíncronas en IndexedDB y la primera
  // puede resolverse DESPUÉS que la segunda, abriendo el proyecto
  // equivocado — y las ediciones irían a parar a ese proyecto. Solo la
  // selección más reciente aplica su resultado; las anteriores se
  // descartan al resolverse.
  const selectSeqRef = useRef(0);
  // False until the persisted drafts load succeeds. While false, no draft
  // sync runs: syncing the initial empty map before the load finished
  // would wipe the very drafts the reload is supposed to restore.
  const draftsReadyRef = useRef(false);
  const projectRef = useRef<Project | null>(null);

  const [metas, setMetas] = useState<ProjectMeta[]>([]);
  const [project, setProject] = useState<Project | null>(null);
  const [activePath, setActivePath] = useState<string | null>(null);
  const [drafts, setDrafts] = useState<Record<string, string>>({});
  const [centerTab, setCenterTab] = useState<CenterTab>('chat');
  const [mobileView, setMobileView] = useState<MobileView>('chat');
  // Proyectos con una generación en curso (por id, no un booleano global:
  // antes, generar en un proyecto desactivaba el chat del proyecto que se
  // estuviera viendo, aunque fuera otro). Un conjunto permite además que
  // dos proyectos generen a la vez: cada uno trabaja sobre su propia foto
  // y el cierre de sendMessage ya fusiona el resultado en el registro
  // guardado si el usuario cambió de proyecto entretanto.
  const [workingIds, setWorkingIds] = useState<string[]>([]);
  const [storageError, setStorageError] = useState<string | null>(null);
  const [pendingDeleteId, setPendingDeleteId] = useState<string | null>(null);
  const [exporting, setExporting] = useState(false);
  const [exportError, setExportError] = useState<string | null>(null);
  const [booted, setBooted] = useState(false);

  const refreshMetas = useCallback(async () => {
    try {
      setMetas(await storageRef.current.listProjects());
    } catch (err) {
      setStorageError(err instanceof Error ? err.message : 'Error de almacenamiento');
    }
  }, []);

  // Initial load: newest project, if any.
  useEffect(() => {
    (async () => {
      try {
        const list = await storageRef.current.listProjects();
        setMetas(list);
        if (list.length > 0) {
          const full = await storageRef.current.getProject(list[0].id);
          if (full) {
            setProject(full);
            setActivePath(full.files.some((f) => f.path === 'index.html') ? 'index.html' : (full.files[0]?.path ?? null));
          }
        }
        // Restore unsaved edits from the previous session. If this fails,
        // draftsReadyRef stays false so no sync can wipe the persisted set.
        // El espejo síncrono de localStorage rescata los borradores que
        // IndexedDB no llegó a sincronizar antes de cerrar la pestaña
        // (debounce de 600 ms): ver editor/drafts.ts.
        setDrafts(mergeDrafts(await storageRef.current.getDrafts(), readDraftsMirror()));
        draftsReadyRef.current = true;
      } catch (err) {
        setStorageError(err instanceof Error ? err.message : 'Error de almacenamiento');
      } finally {
        readyRef.current = true;
        setBooted(true);
      }
    })();
  }, []);

  // Persistencia del proyecto activo, con un camino de vaciado.
  // Antes era con debounce de 600 ms: el temporizador era la única
  // red si la pestaña se cerraba antes de que disparara, y el vaciado
  // asíncrono de pagehide no tiene garantizado completarse (el
  // navegador puede descartar la página con la transacción IndexedDB
  // a medias). Ahora el efecto de abajo guarda en cuanto cambia el
  // proyecto (ver ahí el porqué); este vaciado queda como red de
  // seguridad para una escritura aún en vuelo.
  const persistNow = useCallback(() => {
    const latest = projectRef.current;
    if (!readyRef.current || !latest) return;
    // Un proyecto ya eliminado no vuelve a guardarse: sin este guarda,
    // cambiar al siguiente proyecto tras borrar resucitaría el borrado.
    if (deletedIdsRef.current.has(latest.id)) return;
    storageRef.current
      .saveProject(latest)
      .then(() => {
        setMetas((prev) => {
          const meta = toMeta(latest);
          const next = [meta, ...prev.filter((m) => m.id !== meta.id)];
          next.sort((a, b) => (a.updatedAt < b.updatedAt ? 1 : -1));
          return next;
        });
      })
      .catch((err) =>
        setStorageError(err instanceof Error ? err.message : 'No se pudo guardar'),
      );
  }, []);

  // Vacía el guardado pendiente del proyecto activo ANTES de
  // reemplazarlo en pantalla. El guardado ya es inmediato (ver el
  // efecto de persistencia), así que normalmente no hay nada
  // pendiente; este vaciado cubre la escritura que aún esté en vuelo
  // en el momento del cambio. persistNow guarda el proyecto al que
  // apunta projectRef, que todavía es el proyecto saliente en este punto.
  const flushBeforeSwitch = useCallback(() => {
    persistNow();
  }, [persistNow]);

  // Always have the latest project available for the flush path.
  useEffect(() => {
    projectRef.current = project;
  }, [project]);

  // Same mirror for drafts: sendMessage reads them to detect stale drafts
  // touched by the engine, and must not see a stale closure copy.
  const draftsRef = useRef(drafts);
  useEffect(() => {
    draftsRef.current = drafts;
  }, [drafts]);

  // Debounced persistence of unsaved drafts, with a flush path — same
  // pattern as projects, so an edit survives a reload, a backgrounded
  // tab, or a closed tab. The flush reads draftsRef, never a stale copy.
  const persistDraftsNow = useCallback(() => {
    if (!draftsReadyRef.current) return;
    if (draftsTimerRef.current !== null) {
      window.clearTimeout(draftsTimerRef.current);
      draftsTimerRef.current = null;
    }
    storageRef.current.saveDrafts(draftsRef.current).catch((err) =>
      setStorageError(err instanceof Error ? err.message : 'No se pudieron guardar los borradores'),
    );
  }, []);

  useEffect(() => {
    if (!draftsReadyRef.current) return;
    // Espejo SÍNCRONO en localStorage (ver editor/drafts.ts): se escribe
    // en cada cambio, sin esperar al debounce de IndexedDB, así que
    // cerrar la pestaña dentro de esos 600 ms ya no pierde lo tecleado.
    // El vaciado de pagehide sigue cubriendo la escritura de IndexedDB
    // aún en vuelo, pero los borradores ya no dependen de que complete.
    writeDraftsMirror(drafts);
    draftsTimerRef.current = window.setTimeout(persistDraftsNow, 600);
    return () => {
      if (draftsTimerRef.current !== null) {
        window.clearTimeout(draftsTimerRef.current);
        draftsTimerRef.current = null;
      }
    };
  }, [drafts, persistDraftsNow]);

  // Flush pending changes when the page is hidden or unloaded. El
  // proyecto ya se guarda en cuanto cambia (efecto de abajo), y los
  // borradores ya tienen su espejo síncrono en localStorage (efecto de
  // persistencia de borradores), así que este vaciado cubre sobre todo
  // la escritura de IndexedDB aún en vuelo — de proyecto o de
  // borradores — no la única copia de nada.
  useEffect(() => {
    const onVisibility = () => {
      if (document.visibilityState === 'hidden') {
        persistNow();
        persistDraftsNow();
      }
    };
    const onPageHide = () => {
      persistNow();
      persistDraftsNow();
    };
    window.addEventListener('visibilitychange', onVisibility);
    window.addEventListener('pagehide', onPageHide);
    return () => {
      window.removeEventListener('visibilitychange', onVisibility);
      window.removeEventListener('pagehide', onPageHide);
    };
  }, [persistNow, persistDraftsNow]);

  // Persistencia INMEDIATA del proyecto activo, sin debounce.
  // Los cambios de proyecto son acciones discretas (guardar, crear o
  // borrar un archivo, restaurar una versión, renombrar, resultado del
  // motor), no pulsaciones de teclas: el debounce de 600 ms no
  // ahorraba nada y dejaba una ventana en la que cerrar la pestaña
  // perdía el último cambio si el vaciado asíncrono de pagehide se
  // cortaba (el navegador no garantiza que una transacción IndexedDB
  // iniciada ahí se complete). Con el guardado inmediato esa ventana
  // se cierra: lo guardado ya no va nunca 600 ms por detrás de la
  // pantalla — la causa raíz de las correcciones del 02, 12 y 13-11,
  // que ahora quedan como defensa en profundidad, no como único
  // sostén. Los borradores sí conservan su debounce de 600 ms: ahí
  // cada tecla es un cambio y el vaciado de pagehide sigue
  // cubriéndolos.
  useEffect(() => {
    if (!readyRef.current || !project) return;
    persistNow();
  }, [project, persistNow]);

  const selectProject = useCallback(async (id: string) => {
    // Vaciar el guardado del proyecto saliente antes de reemplazarlo
    // (red de seguridad: el guardado ya es inmediato, pero una
    // escritura aún en vuelo no debe quedarse atrás).
    flushBeforeSwitch();
    const seq = ++selectSeqRef.current;
    try {
      const full = await storageRef.current.getProject(id);
      // Una selección más reciente ganó entretanto: ignorar este
      // resultado aunque haya llegado tarde, o abriría el proyecto
      // equivocado (ver selectSeqRef).
      if (seq !== selectSeqRef.current) return;
      if (!full) return;
      setProject(full);
      // Drafts are scoped per project now: switching projects no longer
      // discards unsaved edits made in another project.
      setActivePath(full.files.some((f) => f.path === 'index.html') ? 'index.html' : (full.files[0]?.path ?? null));
      setCenterTab('chat');
    } catch (err) {
      setStorageError(err instanceof Error ? err.message : 'Error de almacenamiento');
    }
  }, [flushBeforeSwitch]);

  const newProject = useCallback(() => {
    // Igual que al cambiar de proyecto: vaciar el guardado del
    // saliente antes de reemplazarlo (red de seguridad sobre el
    // guardado inmediato).
    flushBeforeSwitch();
    const stamp = nowIso();
    const p: Project = {
      id: newId(),
      name: 'Proyecto sin título',
      createdAt: stamp,
      updatedAt: stamp,
      files: [],
      messages: [welcomeMessage()],
      versions: [],
      generationStatus: 'idle',
    };
    setProject(p);
    setActivePath(null);
    // Drafts of other projects are kept (scoped per project id).
    setCenterTab('chat');
    setMobileView('chat');
  }, [flushBeforeSwitch]);

  const sendMessage = useCallback(
    async (text: string) => {
      if (!project || workingIds.includes(project.id)) return;
      const clean = text.trim();
      if (!clean) return;

      // El motor trabaja sobre esta foto del proyecto, pero el usuario
      // puede cambiar de proyecto mientras genera. Aplicar el resultado
      // a ciegas al final sobrescribiría en pantalla el proyecto que
      // esté viendo entonces (y tiraría sus ediciones intermedias), así
      // que el cierre de esta función comprueba projectRef antes de
      // tocar la pantalla (ver el bloque final).
      const targetId = project.id;
      const snapshotName = project.name;
      // Datos del resultado del motor que el cierre necesita para fusionarlo
      // con lo que el usuario haya editado mientras generaba.
      let engineVersionId: string | null = null;
      let engineSummaryId: string | null = null;
      let engineOps: FileOp[] = [];
      let revealCreatedPath: string | null = null;
      let revealPreview = false;
      let revealChat = false;

      let p: Project = {
        ...project,
        messages: [...project.messages, { id: newId(), role: 'user', content: clean, createdAt: nowIso() }],
        generationStatus: 'working',
      };
      setProject(p);
      setWorkingIds((prev) => (prev.includes(targetId) ? prev : [...prev, targetId]));

      try {
        const isNew = p.files.length === 0;
        const result = isNew
          ? await providerRef.current.generate(clean)
          : await providerRef.current.modify(clean, p.files);
        const report = validateOps(result.ops, p.files);
        const stamp = nowIso();

        if (!report.valid) {
          const errMsg: ChatMessage = {
            id: newId(),
            role: 'assistant',
            createdAt: stamp,
            kind: 'error',
            content:
              'El motor demo produjo operaciones inválidas, así que no se cambió nada:\n' +
              report.errors.map((e) => `• ${e}`).join('\n'),
          };
          p = { ...p, messages: [...p.messages, errMsg], generationStatus: 'error', updatedAt: stamp };
        } else if (result.ops.length === 0) {
          // Informational answer (e.g. help, "already dark") — no file change, no version.
          const infoMsg: ChatMessage = {
            id: newId(),
            role: 'assistant',
            createdAt: stamp,
            kind: 'info',
            content: result.summary,
          };
          p = { ...p, messages: [...p.messages, infoMsg], generationStatus: 'idle', updatedAt: stamp };
        } else {
          const nextFiles = applyOps(p.files, result.ops, stamp);
          // El descarte de borradores y la fusión con ediciones hechas
          // mientras generaba se hacen en el cierre (mergeEngineResult):
          // ahí se sabe qué operaciones siguen encajando y qué borradores
          // son de verdad obsoletos.
          engineOps = result.ops;
          const version: ProjectVersion = {
            id: newId(),
            versionNumber: nextVersionNumber(p.versions),
            files: p.files.map((f) => ({ ...f })),
            createdAt: stamp,
            changeSummary: result.summary.slice(0, 220),
          };
          const planMsg: ChatMessage = {
            id: newId(),
            role: 'assistant',
            createdAt: stamp,
            kind: 'plan',
            content: 'Plan:\n' + result.plan.steps.map((s, i) => `${i + 1}. ${s}`).join('\n'),
          };
          const summaryMsg: ChatMessage = {
            id: newId(),
            role: 'assistant',
            createdAt: stamp,
            kind: 'summary',
            content:
              result.summary +
              (result.warnings.length > 0 ? '\n\nNote: ' + result.warnings.join(' ') : ''),
          };
          engineVersionId = version.id;
          engineSummaryId = summaryMsg.id;
          let name = p.name;
          if (isNew && name === 'Proyecto sin título') {
            name = `Sitio de ${extractBusinessName(clean)}`.slice(0, 80);
          }
          p = {
            ...p,
            name,
            files: nextFiles,
            versions: appendVersion(p.versions, version),
            messages: [...p.messages, planMsg, summaryMsg],
            generationStatus: 'idle',
            updatedAt: stamp,
          };
          const firstCreated = result.ops.find((o) => o.kind === 'create_file');
          if (firstCreated) revealCreatedPath = firstCreated.path;
          revealChat = true;
          // On phones/tablets jump straight to the preview so the result is visible.
          // (Se aplica solo si se sigue en este proyecto; ver el bloque final.)
          if (window.matchMedia('(max-width: 1023px)').matches) {
            revealPreview = true;
          }
        }
      } catch (err) {
        const stamp = nowIso();
        p = {
          ...p,
          messages: [
            ...p.messages,
            {
              id: newId(),
              role: 'assistant',
              createdAt: stamp,
              kind: 'error',
              content: `Algo salió mal al ejecutar el motor demo: ${err instanceof Error ? err.message : 'error desconocido'}. No se cambió nada.`,
            },
          ],
          generationStatus: 'error',
          updatedAt: stamp,
        };
      }

      // Cierre: solo tocar la pantalla cuando se sigue en el proyecto
      // sobre el que trabajó el motor. Si el usuario cambió de proyecto
      // mientras generaba, el resultado va al registro guardado de ese
      // proyecto (ahí estará cuando vuelva a él) en vez de aplastar el
      // proyecto que está viendo, y nunca resucita un proyecto borrado
      // entretanto. Los saltos de vista (archivo creado, chat, móvil a
      // vista previa) también se aplican solo en el primer caso: antes
      // el fin de una generación ajena te cambiaba de pestaña y de vista.
      const current = projectRef.current;
      if (current?.id === targetId) {
        // Un renombrado hecho mientras el motor trabajaba debe sobrevivir:
        // la foto del resultado aún trae el nombre viejo (el motor solo
        // renombra un proyecto nuevo sin título, caso en el que el nombre
        // en pantalla sigue igual que la foto y gana el nombre de p).
        let finalProject = current.name !== snapshotName ? { ...p, name: current.name } : p;
        if (engineVersionId !== null) {
          // Igual que el nombre, las ediciones manuales hechas mientras
          // generaba deben sobrevivir: fusionar las operaciones del motor
          // sobre los archivos en pantalla, no imponer la foto del envío.
          const merged = mergeEngineResult(
            p,
            engineVersionId,
            engineSummaryId,
            engineOps,
            current.files,
            current.versions,
            current.messages,
            draftsRef.current,
          );
          if (merged.appliedPaths.length > 0) {
            setDrafts((prev) => withoutFiles(prev, targetId, merged.appliedPaths));
          }
          finalProject = {
            ...finalProject,
            files: merged.files,
            versions: merged.versions,
            messages: merged.messages,
          };
        } else {
          // Sin cambios de archivos (error o respuesta informativa): el
          // cierre anterior imponía la foto del envío y tiraba las
          // ediciones hechas mientras generaba (guardados, borrados,
          // restauraciones con sus versiones y mensajes). Conservar lo
          // vivo en pantalla y solo añadir el mensaje del motor.
          const newMessages = p.messages.filter(
            (m) => !current.messages.some((cm) => cm.id === m.id),
          );
          finalProject = {
            ...finalProject,
            files: current.files,
            versions: current.versions,
            messages: [...current.messages, ...newMessages],
          };
        }
        setProject(finalProject);
        if (revealCreatedPath) setActivePath(revealCreatedPath);
        if (revealChat) setCenterTab('chat');
        if (revealPreview) setMobileView('preview');
      } else if (!deletedIdsRef.current.has(targetId)) {
        try {
          const stored = await storageRef.current.getProject(targetId);
          if (stored && !deletedIdsRef.current.has(targetId)) {
            // Igual que en pantalla: fusionar sobre lo guardado, porque el
            // usuario pudo volver a este proyecto y editarlo mientras el
            // motor seguía generando.
            let files = p.files;
            let versions = p.versions;
            let messages = p.messages;
            if (engineVersionId !== null) {
              const mergedResult = mergeEngineResult(
                p,
                engineVersionId,
                engineSummaryId,
                engineOps,
                stored.files,
                stored.versions,
                stored.messages,
                draftsRef.current,
              );
              files = mergedResult.files;
              versions = mergedResult.versions;
              messages = mergedResult.messages;
              if (mergedResult.appliedPaths.length > 0) {
                setDrafts((prev) => withoutFiles(prev, targetId, mergedResult.appliedPaths));
              }
            } else {
              // Error o respuesta informativa: no hay cambios de archivos,
              // así que conservar lo guardado (el usuario pudo volver a
              // este proyecto y editarlo mientras generaba) y solo añadir
              // el mensaje del motor, igual que en pantalla.
              files = stored.files;
              versions = stored.versions;
              const newMessages = p.messages.filter(
                (m) => !stored.messages.some((sm) => sm.id === m.id),
              );
              messages = [...stored.messages, ...newMessages];
            }
            // Igual que en pantalla: un renombrado hecho mientras el motor
            // trabajaba debe sobrevivir (gana el nombre guardado si cambió);
            // si el proyecto sigue con el nombre de la foto, gana el nombre
            // automático del motor ("Sitio de …"). Antes, `...stored`
            // imponía "Proyecto sin título" en IndexedDB aunque el motor
            // ya lo hubiera renombrado, y al volver al proyecto la lista
            // lo mostraba sin título pese a tener contenido.
            const name = stored.name !== snapshotName ? stored.name : p.name;
            const merged: Project = {
              ...stored,
              name,
              files,
              messages,
              versions,
              generationStatus: p.generationStatus,
              updatedAt: p.updatedAt,
            };
            await storageRef.current.saveProject(merged);
            const meta = toMeta(merged);
            setMetas((prev) => prev.map((m) => (m.id === meta.id ? meta : m)));
          }
        } catch (err) {
          setStorageError(
            err instanceof Error ? err.message : 'No se pudo guardar el resultado en el proyecto anterior',
          );
        }
      }
      // Quitar solo este proyecto del conjunto: si otro proyecto empezó a
      // generar entretanto, su indicador debe seguir activo.
      setWorkingIds((prev) => prev.filter((id) => id !== targetId));
    },
    [project, workingIds],
  );

  // ---- File editing ----
  const activeFile = project?.files.find((f) => f.path === activePath) ?? null;
  const activeDraftKey = project && activePath ? draftKey(project.id, activePath) : null;
  const editorValue = activeDraftKey && activeDraftKey in drafts ? drafts[activeDraftKey] : (activeFile?.content ?? '');
  const editorDirty = !!activeDraftKey && activeDraftKey in drafts;
  const dirtyPaths = project ? pathsForProject(drafts, project.id) : [];

  const saveFile = useCallback(() => {
    if (!project || !activePath || !activeDraftKey || !(activeDraftKey in drafts)) return;
    const stamp = nowIso();
    const draftContent = drafts[activeDraftKey];
    const current = project.files.find((f) => f.path === activePath);
    // Guardar un borrador idéntico a lo ya guardado no cambia nada: solo
    // se limpia el indicador, sin tocar el proyecto ni crear una versión.
    if (current && draftContent === current.content) {
      setDrafts((prev) => withoutDraft(prev, project.id, activePath));
      return;
    }
    const nextFiles = project.files.map((f) =>
      f.path === activePath ? { ...f, content: draftContent, updatedAt: stamp } : f,
    );
    // Las ediciones manuales no creaban versión: solo el motor dejaba
    // copia antes de cambiar archivos, así que guardar a mano y luego
    // estropear el archivo no tenía vuelta atrás. Guardar ahora deja
    // una copia del estado previo (igual que el motor), salvo que la
    // última versión ya contenga exactamente ese estado.
    const snapshot = snapshotBeforeSave(
      project.files,
      project.versions,
      `Copia antes de guardar ${activePath}`,
      stamp,
    );
    setProject({
      ...project,
      files: nextFiles,
      versions: snapshot ? appendVersion(project.versions, snapshot) : project.versions,
      updatedAt: stamp,
    });
    setDrafts((prev) => withoutDraft(prev, project.id, activePath));
  }, [project, activePath, activeDraftKey, drafts]);

  const createFile = useCallback(
    (name: string): string | null => {
      if (!project) return 'Ningún proyecto seleccionado.';
      if (!PATH_RE.test(name) || name.includes('..')) {
        return 'Usa un nombre de archivo simple (letras, números, guiones, puntos) — sin carpetas.';
      }
      const ext = name.slice(name.lastIndexOf('.')).toLowerCase();
      if (!ALLOWED_EXT.includes(ext)) {
        return `Extensión "${ext || '(ninguna)'}" no permitida. Usa: ${ALLOWED_EXT.join(', ')}.`;
      }
      if (project.files.some((f) => f.path === name)) return 'Ese archivo ya existe.';
      const stamp = nowIso();
      setProject({
        ...project,
        files: [...project.files, { path: name, content: starterFor(name), updatedAt: stamp }],
        updatedAt: stamp,
      });
      setActivePath(name);
      return null;
    },
    [project],
  );

  const deleteFile = useCallback(
    (path: string) => {
      if (!project) return;
      const stamp = nowIso();
      const files = project.files.filter((f) => f.path !== path);
      // Borrar era la única operación destructiva sin punto de retorno:
      // el motor y el guardado manual ya dejan copia, pero eliminar un
      // archivo no. Ahora se guarda el estado previo (con el archivo)
      // para que restaurar esa versión lo devuelva.
      const snapshot = snapshotBeforeSave(
        project.files,
        project.versions,
        `Copia antes de eliminar ${path}`,
        stamp,
      );
      setProject({
        ...project,
        files,
        versions: snapshot ? appendVersion(project.versions, snapshot) : project.versions,
        updatedAt: stamp,
      });
      setDrafts((prev) => withoutDraft(prev, project.id, path));
      if (activePath === path) {
        setActivePath(files.some((f) => f.path === 'index.html') ? 'index.html' : (files[0]?.path ?? null));
      }
    },
    [project, activePath],
  );

  // ---- Versions ----
  const restoreVersion = useCallback(
    (versionId: string) => {
      if (!project) return;
      const v = project.versions.find((x) => x.id === versionId);
      if (!v) return;
      const stamp = nowIso();
      const snapshot: ProjectVersion = {
        id: newId(),
        versionNumber: nextVersionNumber(project.versions),
        files: project.files.map((f) => ({ ...f })),
        createdAt: stamp,
        changeSummary: `Copia de seguridad antes de restaurar la v${v.versionNumber}`,
      };
      const msg: ChatMessage = {
        id: newId(),
        role: 'assistant',
        createdAt: stamp,
        kind: 'summary',
        content: `Restauré la versión v${v.versionNumber} ("${v.changeSummary}"). El estado anterior quedó guardado como v${snapshot.versionNumber}.`,
      };
      setProject({
        ...project,
        files: v.files.map((f) => ({ ...f })),
        versions: appendVersion(project.versions, snapshot),
        messages: [...project.messages, msg],
        updatedAt: stamp,
      });
      // Restoring replaces the files wholesale, so this project's drafts
      // no longer apply — but other projects' drafts are untouched.
      setDrafts((prev) => withoutProjectDrafts(prev, project.id));
      setActivePath(v.files.some((f) => f.path === 'index.html') ? 'index.html' : (v.files[0]?.path ?? null));
      setCenterTab('chat');
    },
    [project],
  );

  // ---- Project management ----
  // Renombrar/duplicar leían la copia guardada en IndexedDB, no el
  // proyecto en memoria: si el proyecto activo tenía cambios recientes
  // aún no persistidos, renombrar lo sobrescribía con la copia vieja y
  // la edición se perdía en silencio. Para el proyecto activo se parte
  // del estado en memoria y el guardado normal lo persiste; para los
  // demás, la copia guardada es la única que existe y sigue siendo
  // correcta. (Con el guardado inmediato del proyecto, la copia
  // guardada ya casi nunca va por detrás; el estado en memoria sigue
  // siendo el más reciente por definición.)
  const renameProject = useCallback(
    async (id: string, name: string) => {
      if (project?.id === id) {
        const updated = { ...project, name, updatedAt: nowIso() };
        setProject(updated);
        setMetas((prev) =>
          prev.map((m) => (m.id === id ? { ...m, name, updatedAt: updated.updatedAt } : m)),
        );
        return;
      }
      const full = await storageRef.current.getProject(id);
      if (!full) return;
      const updated = { ...full, name, updatedAt: nowIso() };
      await storageRef.current.saveProject(updated);
      refreshMetas();
    },
    [project, refreshMetas],
  );

  const duplicateProject = useCallback(
    async (id: string) => {
      const stamp = nowIso();
      const source = project?.id === id ? project : await storageRef.current.getProject(id);
      if (!source) return;
      const copy: Project = {
        ...source,
        id: newId(),
        name: `${source.name} (copy)`.slice(0, 80),
        createdAt: stamp,
        updatedAt: stamp,
        // Una copia no está generando: si el original estaba en plena
        // generación, heredar 'working' dejaría un estado obsoleto que
        // nada volvería a actualizar (el cierre del motor apunta al id
        // original y la copia nunca entra en workingIds).
        generationStatus: 'idle',
      };
      // Los borradores no viven en el registro del proyecto, así que
      // copiar solo el registro dejaba la copia con el contenido
      // guardado y perdía los cambios sin guardar — del todo si luego se
      // borraba el original, porque borrar un proyecto borra sus
      // borradores. La copia hereda los borradores del original (que
      // los conserva); también cubre duplicar un proyecto que no está
      // abierto pero tiene borradores persistidos de otra sesión.
      if (pathsForProject(draftsRef.current, source.id).length > 0) {
        setDrafts((prev) => copyProjectDrafts(prev, source.id, copy.id));
      }
      await storageRef.current.saveProject(copy);
      refreshMetas();
      selectProject(copy.id);
    },
    [project, refreshMetas, selectProject],
  );

  const confirmDeleteProject = useCallback(
    async (id: string) => {
      // Borrar un proyecto era la última operación destructiva sin punto
      // de retorno: eliminaba archivos, chat y versiones de IndexedDB y
      // no quedaba nada. Antes de borrar, se descarga una copia ZIP de
      // respaldo con lo que el editor muestra (borradores incluidos, sin
      // exigir index.html). Si la copia falla, NO se borra nada: mejor
      // un proyecto que sigue existiendo que uno perdido sin respaldo.
      // Un proyecto sin archivos no necesita respaldo.
      try {
        // El respaldo se construye desde el proyecto en memoria cuando se
        // borra el proyecto activo: la copia guardada en IndexedDB puede
        // ir por detrás si el último guardado aún está en vuelo, así que
        // un guardado manual o un archivo creado justo antes de confirmar
        // el borrado no estarían en ella — y el borrador ya se limpió al
        // guardar, así que ni la superposición de borradores lo
        // rescataría: el ZIP prometería una copia completa y el contenido
        // nuevo se perdería para siempre al borrar. El estado en memoria
        // es siempre el más reciente (mismo patrón que renameProject y
        // duplicateProject). Para los demás proyectos la copia guardada
        // es la única que existe y sigue siendo correcta.
        const full =
          project?.id === id ? project : await storageRef.current.getProject(id);
        if (full && full.files.length > 0) {
          // Respaldo COMPLETO: includeSecrets levanta el filtro de
          // nombres sensibles, porque esta copia es la última que queda
          // del proyecto — un archivo como token.txt o secret.md que el
          // filtro dejara fuera se perdería para siempre al borrar, sin
          // versiones ni nada que lo restaure. La exportación normal del
          // usuario mantiene el filtro (ese ZIP sí puede compartirse).
          const blob = await exportProjectZip(full, draftsRef.current, { requireIndex: false, includeSecrets: true });
          const slug = full.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || 'project';
          downloadBlob(blob, `${slug}-respaldo.zip`);
        }
      } catch (err) {
        setExportError(
          `No se pudo crear la copia de respaldo y el proyecto NO se eliminó: ${err instanceof Error ? err.message : 'error desconocido'}. Inténtalo de nuevo o exporta el ZIP a mano antes de borrar.`,
        );
        return;
      }
      await storageRef.current.deleteProject(id);
      // Marcarlo antes de cambiar al siguiente proyecto: el vaciado de
      // selectProject no debe volver a guardar el proyecto borrado.
      deletedIdsRef.current.add(id);
      setPendingDeleteId(null);
      const remaining = metas.filter((m) => m.id !== id);
      setMetas(remaining);
      // The deleted project's drafts go with it; other projects keep theirs.
      setDrafts((prev) => withoutProjectDrafts(prev, id));
      if (project?.id === id) {
        if (remaining.length > 0) {
          selectProject(remaining[0].id);
        } else {
          setProject(null);
          setActivePath(null);
        }
      }
    },
    [metas, project, selectProject],
  );

  // ---- Export ----
  const handleExport = useCallback(async () => {
    if (!project || exporting) return;
    setExporting(true);
    setExportError(null);
    try {
      // Export what the editor shows, not just what is saved: pass the
      // unsaved drafts so the ZIP never ships stale content silently.
      const blob = await exportProjectZip(project, drafts);
      const slug = project.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || 'project';
      downloadBlob(blob, `${slug}.zip`);
    } catch (err) {
      setExportError(err instanceof Error ? err.message : 'Falló la exportación');
    } finally {
      setExporting(false);
    }
  }, [project, drafts, exporting]);

  // ---- Preview ----
  // The preview shows what the editor shows, not just what is saved:
  // unsaved drafts are overlaid onto the project files (same helper the
  // ZIP export uses), so an edit appears in the preview without Ctrl+S.
  // The drafts snapshot is debounced: rebuilding the preview on every
  // keystroke would reload the iframe while the user is still typing
  // (losing scroll position and form state inside the preview), so the
  // preview only picks up edits once typing pauses for 800 ms.
  const [previewDrafts, setPreviewDrafts] = useState<Record<string, string>>({});
  useEffect(() => {
    const timer = window.setTimeout(() => setPreviewDrafts(drafts), 800);
    return () => window.clearTimeout(timer);
  }, [drafts]);
  const previewHtml = useMemo(
    () =>
      project
        ? buildPreviewHtml(overlayDrafts(project.files, previewDrafts, project.id))
        : '',
    [project, previewDrafts],
  );
  // Drafts actually reflected in the preview above (debounced snapshot,
  // not the live map) — so the badge never claims more than the preview
  // is showing.
  const previewUnsavedCount = project
    ? pathsForProject(previewDrafts, project.id).length
    : 0;
  const hasIndex = !!project?.files.some((f) => f.path === 'index.html');

  const centerTabs: Array<{ id: CenterTab; label: string }> = [
    { id: 'chat', label: 'Chat' },
    { id: 'files', label: `Archivos${dirtyPaths.length > 0 ? ` (${dirtyPaths.length})` : ''}` },
    { id: 'versions', label: `Versiones${project ? ` (${project.versions.length})` : ''}` },
  ];

  const mobileTabs: Array<{ id: MobileView; label: string }> = [
    { id: 'projects', label: 'Proyectos' },
    { id: 'chat', label: 'Chat' },
    { id: 'code', label: 'Código' },
    { id: 'preview', label: 'Vista previa' },
  ];

  if (!booted) {
    return (
      <div className="flex h-dvh flex-col items-center justify-center gap-4 bg-[#101114] text-white">
        <span className="inline-block h-12 w-12 animate-pulse rounded-2xl bg-gradient-to-br from-[#7c5cff] to-[#9a82ff]" />
        <p className="text-sm font-semibold text-[#a7abb6]">Cargando NEST Forge AI…</p>
      </div>
    );
  }

  return (
    <div className="flex h-dvh flex-col bg-[#101114] text-white">
      {/* Mobile top bar */}
      <div className="border-b border-[#2a2d36] lg:hidden">
        <div className="flex items-center gap-2 px-4 py-2.5">
          <span className="inline-block h-6 w-6 rounded-lg bg-gradient-to-br from-[#7c5cff] to-[#9a82ff]" />
          <span className="font-extrabold tracking-tight">NEST Forge AI</span>
          <span className="rounded-md border border-[#7c5cff]/50 bg-[#7c5cff]/15 px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-widest text-[#9a82ff]">
            Demo
          </span>
          <button
            onClick={handleExport}
            disabled={!project || exporting}
            className="ml-auto rounded-lg border border-[#2a2d36] bg-[#1d1f26] px-3 py-1.5 text-xs font-semibold text-[#a7abb6] disabled:opacity-40"
          >
            {exporting ? 'Exportando…' : 'Exportar ZIP'}
          </button>
        </div>
        <nav className="flex px-2 pb-2">
          {mobileTabs.map((t) => (
            <button
              key={t.id}
              onClick={() => setMobileView(t.id)}
              className={`flex-1 rounded-lg px-2 py-2 text-xs font-bold ${
                mobileView === t.id ? 'bg-[#7c5cff] text-white' : 'text-[#a7abb6]'
              }`}
            >
              {t.label}
            </button>
          ))}
        </nav>
      </div>

      {storageError && (
        <div className="border-b border-red-900 bg-red-950/60 px-4 py-2 text-xs text-red-200">
          Error de almacenamiento: {storageError} — es posible que los cambios no se guarden.
          <button onClick={() => setStorageError(null)} className="ml-2 underline">Descartar</button>
        </div>
      )}
      {exportError && (
        <div className="border-b border-red-900 bg-red-950/60 px-4 py-2 text-xs text-red-200">
          Falló la exportación: {exportError}
          <button onClick={() => setExportError(null)} className="ml-2 underline">Descartar</button>
        </div>
      )}

      <div className="flex min-h-0 flex-1">
        {/* Left: projects */}
        <div
          className={`${mobileView === 'projects' ? 'flex' : 'hidden'} w-full shrink-0 border-r border-[#2a2d36] lg:flex lg:w-72`}
        >
          <Sidebar
            projects={metas}
            activeId={project?.id ?? null}
            workingIds={workingIds}
            onNew={newProject}
            onSelect={(id) => { selectProject(id); setMobileView('chat'); }}
            onRename={renameProject}
            onDuplicate={duplicateProject}
            onDelete={(id) => setPendingDeleteId(id)}
          />
        </div>

        {/* Center: chat / files / versions */}
        {/* La clave es el proyecto abierto: el estado local de estos
            paneles (borrador del chat, nombre de archivo nuevo,
            confirmación de borrado o de restauración) pertenece a un
            proyecto y no debe sobrevivir al cambio. Sin ella, escribir
            un mensaje en el proyecto A, tocar el proyecto B y pulsar
            Enviar ejecutaba la generación sobre B y modificaba sus
            archivos — el mismo error de "acción en el proyecto
            equivocado" que las correcciones del 02 al 09-11 cerraron
            para carreras y fusiones, pero este ocurría siempre, sin
            doble toque. Renombrar no cambia el id, así que no borra
            un borrador a medio escribir. */}
        <div
          key={project?.id ?? 'sin-proyecto'}
          className={`${mobileView === 'chat' || mobileView === 'code' ? 'flex' : 'hidden'} min-w-0 flex-1 flex-col border-r border-[#2a2d36] lg:flex`}
        >
          <div className="flex items-center gap-1 border-b border-[#2a2d36] px-3 py-2">
            {centerTabs.map((t) => (
              <button
                key={t.id}
                onClick={() => setCenterTab(t.id)}
                className={`rounded-lg px-3 py-1.5 text-xs font-bold ${
                  (mobileView === 'code' ? 'files' : centerTab) === t.id
                    ? 'bg-[#1d1f26] text-white'
                    : 'text-[#5b606c] hover:text-white'
                }`}
              >
                {t.label}
              </button>
            ))}
            <button
              onClick={handleExport}
              disabled={!project || exporting}
              className="ml-auto hidden rounded-lg border border-[#2a2d36] bg-[#1d1f26] px-3 py-1.5 text-xs font-semibold text-[#a7abb6] hover:text-white disabled:opacity-40 lg:block"
            >
              {exporting ? 'Exportando…' : '⤓ Exportar ZIP'}
            </button>
          </div>

          <div className="min-h-0 flex-1">
            {(mobileView === 'code' ? 'files' : centerTab) === 'chat' && (
              project ? (
                <ChatPanel
                  projectName={project.name}
                  messages={project.messages}
                  working={workingIds.includes(project.id)}
                  onSend={sendMessage}
                />
              ) : (
                <EmptyCenter onNew={newProject} />
              )
            )}
            {(mobileView === 'code' ? 'files' : centerTab) === 'files' && (
              project ? (
                <div className="flex h-full flex-col lg:flex-row">
                  <div className="h-44 shrink-0 border-b border-[#2a2d36] lg:h-auto lg:w-60 lg:border-b-0 lg:border-r">
                    <FileExplorer
                      files={project.files}
                      activePath={activePath}
                      dirtyPaths={dirtyPaths}
                      onSelect={setActivePath}
                      onCreate={createFile}
                      onDelete={deleteFile}
                    />
                  </div>
                  <div className="min-h-0 flex-1">
                    {activeFile && activePath ? (
                      <CodeEditor
                        path={activePath}
                        value={editorValue}
                        dirty={editorDirty}
                        onChange={(v) => {
                          if (!project || !activePath) return;
                          setDrafts((prev) => ({ ...prev, [draftKey(project.id, activePath)]: v }));
                        }}
                        onSave={saveFile}
                      />
                    ) : (
                      <div className="flex h-full items-center justify-center p-8 text-center text-sm text-[#5b606c]">
                        Selecciona un archivo para editarlo. Los cambios se marcan hasta que guardes.
                      </div>
                    )}
                  </div>
                </div>
              ) : (
                <EmptyCenter onNew={newProject} />
              )
            )}
            {(mobileView === 'code' ? 'files' : centerTab) === 'versions' && (
              project ? (
                <VersionsPanel versions={project.versions} onRestore={restoreVersion} />
              ) : (
                <EmptyCenter onNew={newProject} />
              )
            )}
          </div>
        </div>

        {/* Right: preview */}
        <div
          className={`${mobileView === 'preview' ? 'flex' : 'hidden'} w-full shrink-0 flex-col lg:flex lg:w-[44%]`}
        >
          <PreviewPanel
            html={previewHtml}
            buildOk={hasIndex}
            buildNote={hasIndex ? 'index.html encontrado y ensamblado' : 'Agrega un index.html para activar la vista previa'}
            fileCount={project?.files.length ?? 0}
            unsavedCount={previewUnsavedCount}
          />
        </div>
      </div>

      {pendingDeleteId && (
        <Modal
          title="¿Eliminar proyecto?"
          message="Antes de eliminarlo se descargará una copia de respaldo en ZIP con sus archivos (incluidos los cambios sin guardar). Si la copia falla, el proyecto no se elimina. El borrado en sí elimina permanentemente el proyecto, su historial del chat y las versiones."
          confirmLabel="Eliminar"
          danger
          onConfirm={() => confirmDeleteProject(pendingDeleteId)}
          onCancel={() => setPendingDeleteId(null)}
        />
      )}
    </div>
  );
}

function EmptyCenter({ onNew }: { onNew: () => void }) {
  return (
    <div className="flex h-full flex-col items-center justify-center p-8 text-center">
      <span className="mb-4 inline-block h-12 w-12 rounded-2xl bg-gradient-to-br from-[#7c5cff] to-[#9a82ff]" />
      <h2 className="mb-2 text-lg font-bold text-white">Ningún proyecto abierto</h2>
      <p className="mb-5 max-w-sm text-sm text-[#a7abb6]">
        Crea un proyecto, describe el sitio web que quieres en el chat y el motor demo
        lo construirá con plantillas reales.
      </p>
      <button
        onClick={onNew}
        className="rounded-xl bg-[#7c5cff] px-5 py-2.5 text-sm font-bold text-white hover:bg-[#9a82ff]"
      >
        + Nuevo proyecto
      </button>
    </div>
  );
}
